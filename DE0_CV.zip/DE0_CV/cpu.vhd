-- Processador Versao 4: 06/08/2025
-- Video com 256 cores e tela de 40 colunas por 30 linhas

library ieee;
use ieee.std_LOGIC_1164.all;
use ieee.std_LOGIC_ARITH.all;
use ieee.std_LOGIC_unsigned.all;

entity cpu is
	port( clk			: in	std_LOGIC;
			reset			: in	std_LOGIC;
			clk_sel		: in	STD_LOGIC_VECTOR(3 downto 0); -- Novo: Seletor de frequencia do clock

			Mem			: in	STD_LOGIC_VECTOR(15 downto 0);
			M5				: out STD_LOGIC_VECTOR(15 downto 0);
			M1				: out STD_LOGIC_VECTOR(15 downto 0);
			RW				: out std_LOGIC;
			
			key			: in	STD_LOGIC_VECTOR(7 downto 0);
			
			videoflag	: out std_LOGIC;
			vga_pos		: out STD_LOGIC_VECTOR(15 downto 0);
			vga_char		: out STD_LOGIC_VECTOR(15 downto 0);
			
			Ponto			: out STD_LOGIC_VECTOR(2 downto 0);
			
			halt_ack		: out	std_LOGIC;
			halt_req		: in	std_LOGIC;
			
			PC_data		: out STD_LOGIC_VECTOR(15 downto 0);
			break 		: out STD_LOGIC;
			
			draw_ack		: in  STD_LOGIC
			
		);
end cpu;

ARCHITECTURE main of cpu is

	TYPE STATES				is (fetch, decode, exec, exec2, halted, stall);				-- Estados da Maquina de Controle (Adicionado 'stall')
	TYPE Registers			is array(0 to 7) of STD_LOGIC_VECTOR(15 downto 0); -- Banco de Registradores
	TYPE LoadRegisters	is array(0 to 7) of std_LOGIC;							-- Sinais de LOAD dos Registradores do Banco

	-- INSTRUCTION SET: 30 INSTRUCTIONS
	-- Data Manipulation Instructions:												-- Usage		    -- Action     	-- Format	
	CONSTANT LOAD			: STD_LOGIC_VECTOR(5 downto 0) := "110000";		-- LOAD RX END  -- RX <- M[END]  Format: < inst(6) | RX(3) | xxxxxxx >  + 16bit END
	CONSTANT STORE			: STD_LOGIC_VECTOR(5 downto 0) := "110001";		-- STORE END RX -- M[END] <- RX  Format: < inst(6) | RX(3) | xxxxxxx >  + 16bit END
	CONSTANT LOADIMED		: STD_LOGIC_VECTOR(5 downto 0) := "111000";		-- LOADN RX Nr   -- RX <- Nr    	Format: < inst(6) | RX(3) | xxxxxxb0 >  + 16bit Numero
	CONSTANT LOADINDEX	: STD_LOGIC_VECTOR(5 downto 0) := "111100";		-- LOADI RX RY   -- RX <- M[RY]	Format: < inst(6) | RX(3) | RY(3) | xxxx >
	CONSTANT STOREINDEX	: STD_LOGIC_VECTOR(5 downto 0) := "111101";		-- STOREI RX RY  -- M[RX] <- RY	Format: < inst(6) | RX(3) | RY(3) | xxxx >
	CONSTANT MOV			: STD_LOGIC_VECTOR(5 downto 0) := "110011";		-- MOV RX RY    -- RX <- RY	  	Format: < inst(6) | RX(3) | RY(3) | xx | x0 >
																								-- MOV RX SP    RX <- SP         Format: < inst(6) | RX(3) | xxx | xx | 01 >
																								-- MOV SP RX    SP <- RX         Format: < inst(6) | RX(3) | xxx | xx | 11 >
																					
	
	-- I/O Instructions:
	CONSTANT OUTCHAR		: STD_LOGIC_VECTOR(5 downto 0) := "110010";		-- OUTCHAR RX RY -- Video[RY] <- Char(RX)		Format: < inst(6) | RX(3) | RY(3) | xxxx >
																								-- RX contem o codigo do caracter de 0 a 127
																								-- RY(10 downto 0) = posicao continua de 0 a 1199 no RY
																								
	CONSTANT INCHAR		: STD_LOGIC_VECTOR(5 downto 0) := "110101";		-- INCHAR RX     -- RX[5..0] <- KeyPressed	RX[15..6] <- 0's  	Format: < inst(6) | RX(3) | xxxxxxx >
	
	CONSTANT ARITH			: STD_LOGIC_VECTOR(1 downto 0) := "10";
	-- Aritmethic Instructions:	
	CONSTANT ADD 			: STD_LOGIC_VECTOR(3 downto 0) := "0000";			
	CONSTANT SUB 			: STD_LOGIC_VECTOR(3 downto 0) := "0001";			
	CONSTANT MULT 			: STD_LOGIC_VECTOR(3 downto 0) := "0010";			
	CONSTANT DIV 			: STD_LOGIC_VECTOR(3 downto 0) := "0011";			
	CONSTANT INC 			: STD_LOGIC_VECTOR(3 downto 0) := "0100";			
	CONSTANT LMOD 			: STD_LOGIC_VECTOR(3 downto 0) := "0101";			

	CONSTANT LOGIC			: STD_LOGIC_VECTOR(1 downto 0) := "01";
	-- LOGIC Instructions:	
	CONSTANT LAND			: STD_LOGIC_VECTOR(3 downto 0) := "0010"; 	
	CONSTANT LOR			: STD_LOGIC_VECTOR(3 downto 0) := "0011";		
	CONSTANT LXOR			: STD_LOGIC_VECTOR(3 downto 0) := "0100"; 	
	CONSTANT LNOT			: STD_LOGIC_VECTOR(3 downto 0) := "0101";		
	CONSTANT SHIFT			: STD_LOGIC_VECTOR(3 downto 0) := "0000";		
	CONSTANT CMP 			: STD_LOGIC_VECTOR(3 downto 0) := "0110";		

	-- FLOW CONTROL Instructions:	
	CONSTANT JMP			: STD_LOGIC_VECTOR(5 downto 0) := "000010";	
	CONSTANT CALL			: STD_LOGIC_VECTOR(5 downto 0) := "000011";	
	CONSTANT RTS			: STD_LOGIC_VECTOR(5 downto 0) := "000100";	
	CONSTANT PUSH			: STD_LOGIC_VECTOR(5 downto 0) := "000101";	
	CONSTANT POP			: STD_LOGIC_VECTOR(5 downto 0) := "000110";	

	-- Control Instructions:		
	CONSTANT NOP			: STD_LOGIC_VECTOR(5 downto 0) := "000000";	
	CONSTANT HALT			: STD_LOGIC_VECTOR(5 downto 0) := "001111";	
	CONSTANT SETC			: STD_LOGIC_VECTOR(5 downto 0) := "001000";	
	CONSTANT BREAKP		: STD_LOGIC_VECTOR(5 downto 0) := "001110"; 	
	
	-- Nova Instrucao de Temporizacao:
	CONSTANT PAUSE			: STD_LOGIC_VECTOR(5 downto 0) := "000111"; 	-- PAUSE RX      -- Espera RX milissegundos   Format: < inst(6) | RX(3) | xxxxxxx >
	
	-- CONSTANTes para controle do Mux2:
	CONSTANT sULA		: STD_LOGIC_VECTOR (2 downto 0) := "000";
	CONSTANT sMem		: STD_LOGIC_VECTOR (2 downto 0) := "001";
	CONSTANT sM4		: STD_LOGIC_VECTOR (2 downto 0) := "010";
	CONSTANT sTECLADO	: STD_LOGIC_VECTOR (2 downto 0) := "011"; 
	CONSTANT sSP		: STD_LOGIC_VECTOR (2 downto 0) := "100";	

	-- Sinais para o Processo da ULA	
	signal OP				: STD_LOGIC_VECTOR(6 downto 0);	
	signal x, y, result	: STD_LOGIC_VECTOR(15 downto 0);
	signal FR				: STD_LOGIC_VECTOR(15 downto 0);	
	signal auxFR			: STD_LOGIC_VECTOR(15 downto 0);	

begin

-- Maquina de Controle
process(clk, reset)

	-- Register Declaration:	
	variable PC		: STD_LOGIC_VECTOR(15 downto 0);		-- Program Counter
	variable IR		: STD_LOGIC_VECTOR(15 downto 0);		-- Instruction Register
	variable SP		: STD_LOGIC_VECTOR(15 downto 0);		-- Stack Pointer
	variable MAR	: STD_LOGIC_VECTOR(15 downto 0);		-- Memory address Register
	VARIABLE	TECLADO	:STD_LOGIC_VECTOR(15 downto 0);		
	
	variable reg : Registers;
	
	-- Registradores de Tempo (64 bits)
	variable timer_counter : STD_LOGIC_VECTOR(63 downto 0);
	variable target_time   : STD_LOGIC_VECTOR(63 downto 0);
	variable cycles_per_ms : STD_LOGIC_VECTOR(15 downto 0);
	variable delay_cycles  : STD_LOGIC_VECTOR(31 downto 0);
	
	-- Mux dos barramentos de dados internos	
	VARIABLE	M2				:STD_LOGIC_VECTOR(15 downto 0);	
	VARIABLE M3, M4		:STD_LOGIC_VECTOR(15 downto 0);	
	VARIABLE	M6				:STD_LOGIC_VECTOR(15 downto 0);	
	
	-- Controle dos registradores internos
	variable LoadReg		: LoadRegisters; 
	variable LoadIR		: std_LOGIC;
	variable LoadMAR		: std_LOGIC;
	variable LoadPC		: std_LOGIC;
	variable IncPC			: std_LOGIC;
	VARIABLE LoadSP	  	: STD_LOGIC;
	variable IncSP			: std_LOGIC;
	variable DecSP			: std_LOGIC;
	variable LoadFR		: std_LOGIC;
		
	-- Selecao dos Mux 2 e 6
	variable selM2 		: STD_LOGIC_VECTOR(2 downto 0); 
	variable selM6 		: STD_LOGIC_VECTOR(2 downto 0); 
	
	VARIABLE BreakFlag	: STD_LOGIC;  
	
	variable state : STATES;  
	
	-- Seletores dos registradores
	variable RX : integer;   
	variable RY : integer;
	variable RZ : integer;
	
begin

	if(reset = '1') then
	
		state := fetch;		
		M1(15 downto 0) <=	x"0000";  
		videoflag <= '0';
		
		RX := 0;
		RY := 0;
		RZ := 0;
		
		RW <= '0';
		
		LoadIR	:= '0';
		LoadMAR	:= '0';
		LoadPC	:= '0';
		IncPC		:= '0';
		IncSP		:= '0';
		DecSP		:= '0';
		LoadSP	:= '0';
		LoadFR	:= '0';
		selM2		:= sMem;
		selM6		:= sULA;
		
		LoadReg(0) := '0'; LoadReg(1) := '0'; LoadReg(2) := '0'; LoadReg(3) := '0';
		LoadReg(4) := '0'; LoadReg(5) := '0'; LoadReg(6) := '0'; LoadReg(7) := '0';
		
		REG(0)  := x"0000"; REG(1)  := x"0000"; REG(2)  := x"0000"; REG(3)  := x"0000";
		REG(4)  := x"0000"; REG(5)  := x"0000"; REG(6)  := x"0000"; REG(7)  := x"0000";
		
		PC := x"0000";  
		SP := x"7ffc";  
		IR := x"0000";
		MAR := x"0000";
			
		BreakFlag:= '0';	
		BREAK <= '0'; 	

		HALT_ack <= '0';
		
		-- Inicializacao dos registradores de tempo
		timer_counter := (others => '0');
		target_time   := (others => '0');
			
	elsif(clk'event and clk = '1') then
	
		-- Incrementa o contador de tempo do sistema a cada ciclo de clock
		timer_counter := timer_counter + x"0000000000000001";
	
		if(LoadIR = '1')	then IR := Mem; 				end if;
		if(LoadPC = '1')	then PC := Mem; 				end if;
		if(IncPC = '1')	then PC := PC + x"0001"; 	end if;
		if(LoadMAR = '1') then MAR := Mem; 				end if;
		if(LoadSP = '1') 	then SP := M4; 				end if;
		if(IncSP = '1')	then SP := SP + x"0001"; 	end if;
		if(DecSP = '1')	then SP := SP - x"0001"; 	end if;
	
		-- Selecao do Mux6
		if (selM6 = sULA) THEN M6 := auxFR;				
		ELSIF (selM6 = sMem) THEN M6 := Mem; END IF;	
		
		if(LoadFR = '1') 	then FR <= M6; 				end if;

		-- Atualiza o indice dos registradores
		RX := conv_integer(IR(9 downto 7));
		RY := conv_integer(IR(6 downto 4));
		RZ := conv_integer(IR(3 downto 1));
	
		-- Selecao do Mux2
		if (selM2 = sULA) 		THEN M2 := RESULT;
		ELSIF (selM2 = sMem) 	THEN M2 := Mem;
		ELSIF (selM2 = sM4) 		THEN M2 := M4;
		ELSIF (selM2 = sTECLADO)THEN M2 := TECLADO;
		ELSIF (selM2 = sSP) 		THEN M2 := SP; 
		END IF;			
		
		if(LoadReg(RX) = '1') then reg(RX) := M2; end if;
	
		-- Reseta os sinais de controle APOS usa-los acima
		LoadIR  := '0';
		LoadMAR := '0';
		LoadPC  := '0';	
		IncPC   := '0';
		IncSP   := '0';
		DecSP   := '0';
		LoadSP  := '0';
		LoadFR  := '0';
		selM6	  := sULA;	

		LoadReg(0) := '0'; LoadReg(1) := '0'; LoadReg(2) := '0'; LoadReg(3) := '0';
		LoadReg(4) := '0'; LoadReg(5) := '0'; LoadReg(6) := '0'; LoadReg(7) := '0';

		if(draw_ack = '1') then videoflag <= '0';	end if;
		
		RW <= '0';  

		if(halt_req = '1') then state := halted; end if;

		PC_data <= PC;

		case state is
--************************************************************************
-- FETCH STATE
--************************************************************************		
		
		when fetch =>
			PONTO <= "001";
			
			M1 <= PC;
			RW <= '0';
			LoadIR := '1';
			IncPC := '1';

			STATE := decode;

--************************************************************************
-- DECODE STATE
--************************************************************************
		when decode =>
			PONTO <= "010";

--========================================================================
-- PAUSE RX               Espera RX milissegundos
--========================================================================
			IF(IR(15 DOWNTO 10) = PAUSE) THEN
				-- Seleciona a quantidade de ciclos por milissegundo conforme 'clk_sel'
				case clk_sel is
					when "0001"   => cycles_per_ms := x"30D4"; -- 12.5 MHz (12.500 ciclos/ms)
					when "0010"   => cycles_per_ms := x"03E8"; -- 1 MHz (1.000 ciclos/ms)
					when "0100"   => cycles_per_ms := x"0064"; -- 100 Khz (100 ciclos/ms)
					when "1000"	  => cycles_per_ms := x"000A"; -- 10 Khz (10 ciclos/ms)
					when others   => cycles_per_ms := x"0001"; -- outros clocks sao mt lentos, n precisa esperar
					
				end case;

				-- Reg(RX) contem o valor de milissegundos a esperar
				delay_cycles := Reg(RX) * cycles_per_ms;
				
				-- Calcula o instante de tempo futuro para saida do stall
				target_time  := timer_counter + (x"00000000" & delay_cycles);

				state := stall;
			END IF;

--========================================================================
-- INCHAR  			RX[7..0] <- KeyPressed	RX[15..8] <- 0
--========================================================================		
			IF(IR(15 DOWNTO 10) = INCHAR) THEN 
				TECLADO(7 downto 0) := key(7 downto 0);
				TECLADO(15 downto 8) := X"00";

				selM2 := sTECLADO;
				LoadReg(RX) := '1';
				state := fetch;
			END IF;			
			
--========================================================================
-- OUTCHAR			Video[RY] <- Char(RX)
--========================================================================
			IF(IR(15 DOWNTO 10) = OUTCHAR) THEN
				M3 := Reg(Rx); 							
				M4 := Reg(Ry); 							

				if M3(15 downto 8) = "00000000" then
               M3(15 downto 8) := "11111111";
            end if;

				vga_char <= M3; 
				vga_pos	<= M4;  
				videoflag <= '1';  
				state := fetch;		
			END IF;					

--========================================================================
-- LOAD Imediato 			RX <- Nr
--========================================================================			
			IF(IR(15 DOWNTO 10) = LOADIMED) THEN
				M1 <= PC;				
				Rw <= '0';				
				selM2 := sMeM; 			
				LoadReg(RX) := '1';	
				IncPC := '1';  			
				state := fetch;
			END IF;		

--========================================================================
-- LOAD Direto  			RX <- M[End]
--========================================================================		
			IF(IR(15 DOWNTO 10) = LOAD) THEN 
				M1 <= PC;
				Rw <= '0';	
				LoadMar := '1';
				IncPC := '1';
				
				state := exec;  
			END IF;			

--========================================================================
-- STORE DIReto			M[END] <- RX
--========================================================================			
			IF(IR(15 DOWNTO 10) = STORE) THEN  
				M1 <= PC;
				Rw <= '0';	
				LoadMar := '1';
				IncPC := '1';
				
				state := exec;  
			END IF;					

--========================================================================
-- LOAD Indexado por registrador 			RX <- M(RY)
--========================================================================		
			IF(IR(15 DOWNTO 10) = LOADINDEX) THEN
				M4 := REG(RY);
				M1 <= M4;		  
				
				Rw <= '0';		
				selM2 := sMeM; 
				loadReg(RX) := '1';

				state := fetch;
			END IF;					
		
--========================================================================
-- STORE indexado por registrador 			M[RX] <- RY
--========================================================================		
			IF(IR(15 DOWNTO 10) = STOREINDEX) THEN 
				M4 := REG(RX);
				M1 <= M4;		
				
				Rw <= '1';
				M3 := REG(RY);
				M5 <= M3;		
				
				state := fetch;
			END IF;					

--========================================================================
-- MOV  			RX/SP <- RY/SP
--========================================================================		
			IF(IR(15 DOWNTO 10) = MOV) THEN 
				IF(IR(0) = '0') THEN
					M4 := REG(RY);
					selM2 := sM4;
					LoadReg(RX) := '1';
					
				ELSIF(IR(1) = '0') THEN
					selM2 := sSP;
					LoadReg(RX) := '1';
				ELSE
					M4 := REG(RX);
					SP := M4;
				END IF;
			  
				state := fetch;
			END IF;

--========================================================================
-- ARITH OPERATION 			RX <- RY (?) RZ
--========================================================================
			IF(IR(15 DOWNTO 14) = ARITH AND IR(13 DOWNTO 10) /= INC) THEN
				M3 := REG(RY);
				M4 := REG(RZ);
				
				X <= M3;
				y <= M4;
				
				Op(5 downto 0) <= Ir(15 downto 10);
				op(6) <= Ir(0);
				
				selM2 := sULA;
				LoadReg(RX) := '1';
				
				selM6 := sULA;
				LoadFR := '1';
				
				state := fetch;
			END IF;
			
--========================================================================
-- INC/DEC			RX <- RX (+ or -) 1
--========================================================================			
			IF(IR(15 DOWNTO 14) = ARITH AND (IR(13 DOWNTO 10) = INC))	THEN
				M3 := reg(RX);
				M4 := "0000000000000001";
				
				X <= M3;
				y <= M4;
				
				Op(5 downto 4) <= ARITH;
				op(6) <= Ir(0);
				
				IF(Ir(6) = '0') THEN
					Op(3 downto 0) <= ADD;
				ELSE
					Op(3 downto 0) <= SUB;
				END IF;
				
				selM2 := sULA;
				LoadReg(RX) := '1';
				
				selM6 := sULA;
				LoadFR := '1';
				state := fetch;
			END IF;
			
--========================================================================
-- LOGIC OPERATION 			RX <- RY (?) RZ
--========================================================================		
			IF(IR(15 DOWNTO 14) = LOGIC AND IR(13 DOWNTO 10) /= SHIFT AND IR(13 DOWNTO 10) /= CMP) THEN 
				M3 := REG(RY);
				M4 := REG(RZ);
				
				X <= M3;
				Y <= M4;
				
				Op(5 downto 0) <= Ir(15 downto 10);
				
				selM2 := sULA;
				LoadReg(RX):= '1';
				
				state := fetch;
			END IF;			

--========================================================================
-- SHIFT
--========================================================================		
			IF(IR(15 DOWNTO 14) = LOGIC and (IR(13 DOWNTO 10) = SHIFT)) THEN
				if(IR(6 DOWNTO 4) = "000") then	 	-- SHIFT LEFT 0
					Reg(RX) := To_StdLOGICVector(to_bitvector(Reg(RY))sll conv_integer(IR(3 DOWNTO 0)));
				elsif(IR(6 DOWNTO 4) = "001") then	-- SHIFT LEFT 1
					Reg(RX) := not (To_StdLOGICVector(to_bitvector(not Reg(RY))sll conv_integer(IR(3 DOWNTO 0))));
				elsif(IR(6 DOWNTO 4) = "010") then	-- SHIFT RIGHT 0
					Reg(RX) := To_StdLOGICVector(to_bitvector(Reg(RY))srl conv_integer(IR(3 DOWNTO 0)));
				elsif(IR(6 DOWNTO 4) = "011") then	-- SHIFT RIGHT 1
					Reg(RX) := not (To_StdLOGICVector(to_bitvector(not Reg(RY))srl conv_integer(IR(3 DOWNTO 0))));
				elsif(IR(6 DOWNTO 5) = "11") then	-- ROTATE RIGHT
					Reg(RX) := To_StdLOGICVector(to_bitvector(Reg(RY))ror conv_integer(IR(3 DOWNTO 0)));
				elsif(IR(6 DOWNTO 5) = "10") then	-- ROTATE LEFT
					Reg(RX) := To_StdLOGICVector(to_bitvector(Reg(RY))rol conv_integer(IR(3 DOWNTO 0)));
				end if;	
				
				state := fetch;
			end if;			

--========================================================================
-- CMP		RX, RY
--========================================================================		
			IF(IR(15 DOWNTO 14) = LOGIC AND IR(13 DOWNTO 10) = CMP) THEN 
				M3 := REG(RX);
				M4 := REG(RY);
				
				X <= M3;
				y <= M4;
				
				Op(5 downto 0) <= Ir(15 downto 10);
				
				selM6 := sULA;
				Loadfr := '1';
				
				state := fetch;
			END IF;
		
--========================================================================
-- JMP END
--========================================================================		
			IF(IR(15 DOWNTO 10) = JMP) THEN 
				IF((IR(9 DOWNTO 6) = "0000") OR
				((IR(9 DOWNTO 6) = "0111") AND FR(0) = '1') OR
				((IR(9 DOWNTO 6) = "1001") AND (FR(2) = '1' OR FR(0) = '1')) OR
				((IR(9 DOWNTO 6) = "1000") AND FR(1) = '1') OR
				((IR(9 DOWNTO 6) = "1010") AND (FR(2) = '1' OR FR(1) = '1')) OR
				((IR(9 DOWNTO 6) = "0001") AND FR(2) = '1') OR
				((IR(9 DOWNTO 6) = "0010") AND FR(2) = '0') OR
				((IR(9 DOWNTO 6) = "0011") AND FR(3) = '1') OR
				((IR(9 DOWNTO 6) = "0100") AND FR(3) = '0') OR
				((IR(9 DOWNTO 6) = "0101") AND FR(4) = '1') OR
				((IR(9 DOWNTO 6) = "0110") AND FR(4) = '0') OR
				((IR(9 DOWNTO 6) = "1011") AND FR(5) = '1') OR
				((IR(9 DOWNTO 6) = "1100") AND FR(5) = '0') OR
				((IR(9 DOWNTO 6) = "1101") AND FR(6) = '1') OR
				((IR(9 DOWNTO 6) = "1110") AND FR(9) = '1')) THEN
					M1 <= PC;				
					Rw <= '0';				
					LoadPC := '1';			
				ELSE
					IncPC := '1';
				END IF;
				
				state := fetch;
			END IF;
			
--========================================================================
-- CALL END
--========================================================================
			IF(IR(15 DOWNTO 10) = CALL) THEN 
				IF((IR(9 DOWNTO 6) = "0000") OR
				((IR(9 DOWNTO 6) = "0111") AND FR(0) = '1') OR
				((IR(9 DOWNTO 6) = "1001") AND (FR(2) = '1' OR FR(0) = '1')) OR
				((IR(9 DOWNTO 6) = "1000") AND FR(1) = '1') OR
				((IR(9 DOWNTO 6) = "1010") AND (FR(2) = '1' OR FR(1) = '1')) OR
				((IR(9 DOWNTO 6) = "0001") AND FR(2) = '1') OR
				((IR(9 DOWNTO 6) = "0010") AND FR(2) = '0') OR
				((IR(9 DOWNTO 6) = "0011") AND FR(3) = '1') OR
				((IR(9 DOWNTO 6) = "0100") AND FR(3) = '0') OR
				((IR(9 DOWNTO 6) = "0101") AND FR(4) = '1') OR
				((IR(9 DOWNTO 6) = "0110") AND FR(4) = '0') OR
				((IR(9 DOWNTO 6) = "1011") AND FR(5) = '1') OR
				((IR(9 DOWNTO 6) = "1100") AND FR(5) = '0') OR
				((IR(9 DOWNTO 6) = "1101") AND FR(6) = '1') OR
				((IR(9 DOWNTO 6) = "1110") AND FR(9) = '1')) THEN
					Rw <= '1';
					M1 <= SP;
					M5 <= PC;
					
					decSP := '1';
					state := exec;
				ELSE
					IncPC := '1';
					state := fetch;
				END IF;
			END IF;

--========================================================================
-- RTS
--========================================================================				
			IF(IR(15 DOWNTO 10) = RTS) THEN
				incSP := '1';
				state := exec;
			END IF;

--========================================================================
-- PUSH RX
--========================================================================		
			IF(IR(15 DOWNTO 10) = PUSH) THEN
				M1 <= SP;
				RW <= '1';
				IF(IR(6) = '0') THEN
					M3 := REG(RX);
				ELSE
					M3 := FR;
				END IF;
				
				M5 <= M3;
				DecSP := '1';
				
				state := fetch;
			END IF;
		
--========================================================================
-- POP RX
--========================================================================
			IF(IR(15 DOWNTO 10) = POP) THEN
				incSP := '1';
				state := exec;
			END IF;						
				
--========================================================================
-- NOP
--========================================================================
			IF( IR(15 DOWNTO 10) = NOP) THEN 
				state := fetch;
			end if;

--========================================================================
-- HALT
--========================================================================
			IF( IR(15 DOWNTO 10) = HALT) THEN 
				state := halted;
			END IF;		
			
--========================================================================
-- SETC/CLEARC
--========================================================================			
			IF( IR(15 DOWNTO 10) = SETC) THEN 
				FR(4) <= IR(9);  
				state := fetch;
			end if;
			
--========================================================================
-- BREAKP
--========================================================================			
			IF( IR(15 DOWNTO 10) = BREAKP) THEN 
				BreakFlag := not(BreakFlag);  
				BREAK <= BreakFlag;
				state := fetch;	
				PONTO <= "101";
			END IF;		

--************************************************************************
-- STALL STATE (Aguardando o tempo limite passar)
--************************************************************************
		when stall =>
			PONTO <= "110";
			if (timer_counter = target_time) then
				state := fetch;
			else
				state := stall;
			end if;

--************************************************************************
-- EXECUTE STATE
--************************************************************************								
		when exec =>
			PONTO <= "100";

			IF(IR(15 DOWNTO 10) = LOAD) THEN
				M1 <= MAR;
				RW <= '0';
				selM2 := sMem;
				LoadReg(RX) := '1';
				
				state := fetch;
			END IF;
							
			IF(IR(15 DOWNTO 10) = STORE) THEN 
				m1 <= MAR;
				RW <= '1';
				M3 := Reg(RX);
				M5 <= M3;
				
				state := fetch;
			END IF;

			IF(IR(15 DOWNTO 10) = CALL) THEN
				M1 <= PC;
				RW <= '0';
				LoadPC := '1';
				
				state := fetch;
			END IF;

			IF(IR(15 DOWNTO 10) = RTS) THEN
				M1 <= SP;				
				Rw <= '0';				
				LoadPC := '1';	
				
				state := exec2;
			END IF;
			
			IF(IR(15 DOWNTO 10) = POP) THEN
				M1 <= SP;
				RW <= '0';
				
				IF(IR(6) = '0') THEN
					selM2 := sMem;
					LoadReg(RX) := '1';
				ELSE
					selM6 := sMem;
					LoadFR := '1';
				END IF;
				
				state := fetch;
			END IF;		
		
--************************************************************************
-- EXECUTE2 STATE
--************************************************************************								
		when exec2 =>
			PONTO <= "100";				
			IF(IR(15 DOWNTO 10) = RTS) THEN
				IncPC := '1';
				state := fetch;
			END IF;

--************************************************************************
-- HALT STATE
--************************************************************************				
		WHEN halted =>
			PONTO <= "111";	
			state := halted;
			halt_ack <= '1';
			
		WHEN OTHERS =>
			state := fetch;
			videoflag <= '0';
			PONTO <= "000";
		
		END CASE;	
		
	end if;	
	end process;

--************************************************************************
-- ULA
--************************************************************************
PROCESS (OP, X, Y, reset)

	VARIABLE AUX		: STD_LOGIC_VECTOR(15 downto 0);
	VARIABLE RESULT32 : STD_LOGIC_VECTOR(31 downto 0);	
	
BEGIN

	IF (reset = '1') THEN
		auxFR <= x"0000";		
		RESULT <= x"0000";
	else
		auxFR <= FR;

		IF (OP (5 downto 4) = ARITH) THEN
			CASE OP (3 downto 0) IS
				WHEN ADD =>
					IF (OP(6) = '1') THEN 
						AUX := X + Y + FR(4);
						RESULT32 := (x"00000000" + X + Y + FR(4));
					ELSE  
						AUX := X + Y;
						RESULT32 := (x"00000000" + X + Y);					
					end if;	
					if(RESULT32 > "01111111111111111") THEN 
						auxFR(4) <= '1';
					ELSE
						auxFR(4) <= '0';
					end if;
					
				WHEN SUB =>
					AUX := X - Y;
					
				WHEN MULT =>
					RESULT32 := X * Y;
					AUX := RESULT32(15 downto 0);
					if(RESULT32 > x"0000FFFF") THEN 
						auxFR(5) <= '1';
					ELSE
						auxFR(5) <= '0';
					end if;

				WHEN DIV =>
					IF(Y = x"0000") THEN
						AUX := x"0000";
						auxFR(6) <= '1'; 
					ELSE
						AUX := CONV_STD_LOGIC_VECTOR(CONV_INTEGER(X)/CONV_INTEGER(Y), 16);		
						auxFR(6) <= '0';
					END IF;
				WHEN LMOD =>
					IF(Y = x"0000") THEN
						AUX := x"0000";
						auxFR(6) <= '1'; 
					ELSE
						AUX := CONV_STD_LOGIC_VECTOR(CONV_INTEGER(X) mod CONV_INTEGER(Y), 16);		
						auxFR(6) <= '0';
					END IF;			
				WHEN others =>   
					AUX := X;
			END CASE;
			if(AUX = x"0000") THEN
				auxFR(3) <= '1';  
			ELSE
				auxFR(3) <= '0';  
			end if;
			if(AUX < x"0000") THEN   
				auxFR(9) <= '1';  
			ELSE
				auxFR(9) <= '0';  
			end if;	
			RESULT <= AUX;
			
		ELSIF (OP (5 downto 4) = LOGIC) THEN
			IF (OP (3 downto 0) = CMP) THEN
				result <= x;
				IF (x > y) THEN
					auxFR(2 downto 0) <= "001"; 
				ELSIF (x < y) THEN
					auxFR(2 downto 0) <= "010"; 
				ELSIF (x = y) THEN
					auxFR(2 downto 0) <= "100"; 
				END IF;
			ELSE
				CASE OP (3 downto 0) IS
					WHEN LAND => result <= x and y;
					WHEN LXOR => result <= x xor y;
					WHEN LOR  => result <= x or y;
					WHEN LNOT => result <= not x;
					WHEN others => RESULT <= X;
				END CASE;
				if(result = x"0000") THEN
					auxFR(3) <= '1';  
				ELSE
					auxFR(3) <= '0';  
				end if;	
			END IF;
		END IF;
	END IF; 
END PROCESS;

end main;