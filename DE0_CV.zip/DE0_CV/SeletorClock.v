module SeletorClock (
    input clock,
    input reset,
    input [3:0] sel,
    input clock_1hz,
    input clock_10hz,
    input clock_100hz,
    input clock_1khz,
    input clock_10khz,
    input clock_100khz,
    input clock_1mhz,
    input clock_12mhz,
    output reg clock_saida,
    output reg [3:0] selected  // Declared as 'reg' because it is assigned in an always block
);

    always @(posedge clock or posedge reset) begin
        if (reset) begin
            clock_saida <= 1'b0;
            selected    <= 4'b0000;
        end
        else begin
            case (sel)
                4'h0: begin
                    clock_saida <= clock_1hz;
                    selected    <= 4'b0000;
                end
                4'h1: begin
                    clock_saida <= clock_10hz;
                    selected    <= 4'b0000;
                end
                4'h2: begin
                    clock_saida <= clock_100hz;
                    selected    <= 4'b0000;
                end
                4'h3: begin
                    clock_saida <= clock_1khz;
                    selected    <= 4'b0000;
                end
                4'h4: begin
                    clock_saida <= clock_10khz;
                    selected    <= 4'b1000;
                end
                4'h5: begin
                    clock_saida <= clock_100khz;
                    selected    <= 4'b0100;
                end
                4'h6: begin
                    clock_saida <= clock_1mhz;
                    selected    <= 4'b0010;
                end
                4'h7: begin
                    clock_saida <= clock_12mhz;
                    selected    <= 4'b0001;
                end
                4'h8: begin
                    clock_saida <= clock;
                    selected    <= 4'b0000;
                end
                default: begin
                    clock_saida <= 1'b0;
                    selected    <= 4'b0000;
                end
            endcase
        end
    end

endmodule